// import Image from 'next/image';

import { AccordionList } from "@/components/AccordionList/AccordionList";
import { Badge } from "@/components/Badge/Badge";
import { Button } from "@/components/Button/Button";
import ContactForm from "@/components/ContactForm/ContactForm";
import { Container } from "@/components/Container/Container";
import { RatingList } from "@/components/RatingList/RatingList";
import { Slider } from "@/components/Slider/Slider";
import { Table } from "@/components/Table/Table";
import { TextInput } from "@/components/TextInput/TextInput";
import { LandingPage } from "@/pages";
import { Wix_Madefor_Text } from "next/font/google";

const wixMadeforText = Wix_Madefor_Text({
  variable: "--font-wix-madefor-text",
  subsets: ["cyrillic", "latin"],
});
// export default function Home() {
//   return (
//     <>
//       <header className="w-full py-[37px] border-2 border-amber-200">
//         <div className="max-w-content mx-auto flex justify-between">
//           <div className="flex gap-[64px] items-center">
//             <a href="#" className="bg-[url(/logo.svg)] w-[145px] h-[39px]"></a>
//             <nav>
//               <ul className="flex gap-[24px] text-h4 text-text-color leading-[1]">
//                 <li>
//                   <a href="">Цены</a>
//                 </li>
//                 <li>
//                   <a href="">О нас</a>
//                 </li>
//                 <li>
//                   <a href="">FAQ</a>
//                 </li>
//                 <li>
//                   <a href="">Блог</a>
//                 </li>
//                 <li>
//                   <a href="">Сравнение</a>
//                 </li>
//                 <li>
//                   <a href="">Документация</a>
//                 </li>
//               </ul>
//             </nav>
//           </div>
//           <div className="flex gap-[32px] items-center">
//             <a href="#" className="text-white text-[20px] leading-[20px]">
//               Войти
//             </a>
//             <Button size="md">Регистрация</Button>
//           </div>
//         </div>
//       </header>
//       <main
//         className={`bg-background ${wixMadeforText.variable} relative -z-10`}
//       >
//         <section className="relative pt-[34px] pb-[380px] hero-before-image-lines border-2 border-amber-300 mb-7 hero-decor-2">
//           <div className="max-w-[1316px] mx-auto flex flex-col items-center justify-between h-[667px]">
//             <Badge>
//               Идеальные решения для ваших задач на нашем маркетплейсе
//             </Badge>
//             <h1 className="text-h1 leading-[0.85] font-[600] font-main text-center ">
//               Маркетплейс GPU с анализом 200+ провайдеров каждый день
//             </h1>
//             {/* <p className="text-lg font-[600] font-main">Test</p> */}
//             <p className="text-text-color text-subtitle text-center font-main">
//               Сравнивайте характеристики, читайте отзывы и выбирайте именно то,
//               что подходит для ваших уникальных потребностей и бюджета.
//             </p>
//             <Button size="lg" outline>
//               Присоединиться бесплатно&nbsp;&#10230;
//             </Button>
//           </div>
//         </section>
//         {/* <section className="relative before-image pb-[12px]">
//           <Container>
//             <div className="relative w-full h-[810px] bg-black z-1 hero-before-image-outline rounded-[32px]"></div>
//           </Container>
//         </section> */}
//         <section className="relative features-decor-1 pt-[80px] pb-[60px] border-2 border-amber-200">
//           <Container className="flex flex-col items-start">
//             <Badge>Наши преимущества</Badge>
//             <h2 className="text-h2 leading-[0.85] font-[600] font-main max-w-[531px] mt-[32px] mb-[80px]">
//               Почему&nbsp;именно QuData?
//             </h2>
//             <div className="grid grid-cols-1 gap-[20px] lg:grid-cols-[minmax(0,_480px)_minmax(0,_280px)_minmax(0,_640px)] relative features-decor-2-3">
//               <div className="gradient-features-card-1">
//                 <div className="h-[651px] rounded-[23px] relative features-decor-card1-1-2 backdrop-blur-[60px]">
//                   <div className="flex flex-col gap-[40px] text-center max-w-[298px] mx-auto mt-[32px]">
//                     <h3 className="text-h3  leading-[1] font-[600]">
//                       Комплексный анализ глобальных рынков
//                     </h3>
//                     <span className="text-[20px] leading-[1.3] text-text-color">
//                       Находим и рекомендуем самые выгодные и лучшие
//                       GPU-мощности&nbsp;для&nbsp;вас&nbsp;и&nbsp;ваших&nbsp;задач
//                     </span>
//                   </div>
//                 </div>
//               </div>

//               {/* <div className="gradient-border"> */}
//               <div className="h-[651px] border border-[#747474] rounded-[23px] features-decor-card2 backdrop-blur-[60px]"></div>
//               {/* </div> */}
//               <div className="flex flex-col gap-[20px] ">
//                 <div className="gradient-features-card-3">
//                   <div className=" h-[250px] rounded-[23px] features-decor-card3-1-2 backdrop-blur-[60px]">
//                     <div className="flex flex-col gap-[40px] max-w-[298px] mt-[32px] ml-[32px]">
//                       <h3 className="text-h3  leading-[1] font-[600]">
//                         Таблица сравнений
//                       </h3>
//                       <span className="text-[20px] leading-[1.3] text-text-color">
//                         Изучайте и сравнивайте между собой GPU и их провайдеров
//                         по всевозможным фильтрам
//                       </span>
//                     </div>
//                   </div>
//                 </div>
//                 <div className="gradient-features-card-4">
//                   <div className=" h-[381px] rounded-[23px] flex items-center features-decor-card4 backdrop-blur-[60px]">
//                     <div className="flex flex-col gap-[40px] text-center items-center">
//                       <h3 className="text-h3  leading-[1] font-[600]">
//                         Присоединяйтесь к платформе и контролируйте динамику цен
//                         в реальном времени!
//                       </h3>
//                       <Button size="md" outline>
//                         Присоединиться прямо сейчас
//                       </Button>
//                     </div>
//                   </div>
//                 </div>
//               </div>
//             </div>
//           </Container>
//         </section>
//         <section className="pt-[80px]">
//           <Container className="flex flex-col items-center">
//             <Badge>Лучшие предложения</Badge>
//             <h2 className="text-h2 mt-[32px] mb-[80px]">
//               Выбирайте самые выгодные мощности
//             </h2>
//             <div className="w-full offers-decor">
//               <Table />
//             </div>
//             <Button size="lg" outline className="w-full mt-[80px]">
//               Смотреть все модели GPU
//             </Button>
//           </Container>
//         </section>
//         <section className="pt-[80px]">
//           <Container className="flex flex-col">
//             <div className="flex justify-between">
//               <div className="flex flex-col max-w-[557px] items-start">
//                 <Badge>Рекомендации</Badge>
//                 <h2 className="text-h2 leading-[1] mt-[32px] mb-[80px]">
//                   Лучшие провайдеры в России
//                 </h2>
//                 <span>
//                   Ознакомьтесь и выберите для себя лучший вариант провайдер,
//                   основываясь на: отзывах, нашей оценке, предложениях,
//                   посещаемости и многому другому.
//                 </span>
//               </div>
//               <RatingList />
//             </div>
//             <Button size="lg" outline className="w-full mt-[88px]">
//               Смотреть все предложения
//             </Button>
//           </Container>
//         </section>
//         <section className="py-[80px]">
//           <Container className="flex flex-col">
//             <Badge className="self-center">Карта мира с ценами</Badge>
//             <div>Карта</div>
//             <Button size="lg" outline className="w-full mt-[88px]">
//               Смотреть все
//             </Button>
//           </Container>
//         </section>
//         <section className="pt-[80px] pb-[76px] flex flex-col learn-decor-test">
//           {/* <Container className="flex flex-col"> */}
//           <Badge className="self-center mb-[48px]">Статьи</Badge>
//           <h2 className="text-h2 leading-[1] self-center mb-[100px]">
//             Читайте больше о GPU
//           </h2>
//           <Slider />
//           <Button size="lg" outline className=" mt-[100px] self-center">
//             Узнать больше о GPU
//           </Button>
//           {/* </Container> */}
//         </section>
//         <section className="pt-[80px] pb-[80px] faq-decor overflow-visible">
//           <Container className="max-w-[1001px] flex flex-col gap-[120px]">
//             <div className="flex flex-col gap-[32px]">
//               <Badge className="self-center">Раздел FAQ</Badge>
//               <h2 className="text-h2 leading-[1] text-center">
//                 Часто задаваемые вопросы
//               </h2>
//             </div>
//             <div>
//               <AccordionList />
//             </div>
//           </Container>
//         </section>
//         <section className="pt-[80px] pb-[80px] joinus-decor">
//           <Container className="flex flex-col rounded-[23px] py-[48px] gap-[64px] bg-[linear-gradient(152deg,_rgba(66,_66,_66,_0.2)_0%,_rgba(0,_0,_0,_0.2)_100%)] joinus-outline joinus-gradient-border">
//             <div className="flex flex-col items-center gap-[32px]">
//               <h2 className="text-h2 leading-[1]">
//                 Присоединяйтесь к и выбирайте лучшее
//               </h2>
//               <span className="text-[24px] text-center max-w-[820px]">
//                 Запускайте модели машинного обучения, рендеринг и сложные
//                 вычисления без инвестиций в оборудование
//               </span>
//             </div>
//             <div className="flex justify-center gap-[96px]">
//               <div className="flex flex-col items-center gap-[24px] text-center max-w-[216px] joinus-side-border">
//                 <span className="text-title-color text-subtitle leading-[1] max-w-[190px]">
//                   Низкие цены
//                 </span>
//                 <span className="leading-[1]">
//                   Мы отбираем самые выгодные предложения со всего рынка
//                 </span>
//               </div>
//               <div className="flex flex-col items-center gap-[24px] text-center max-w-[216px] joinus-side-border">
//                 <span className="text-title-color text-subtitle leading-[1] max-w-[190px]">
//                   Большой выбор
//                 </span>
//                 <span className="leading-[1]">
//                   Выбирайте необходимые мощности под свои задачи
//                 </span>
//               </div>
//               <div className="flex flex-col items-center gap-[24px] text-center max-w-[216px]">
//                 <span className="text-title-color text-subtitle leading-[1] max-w-[190px]">
//                   Удобный маркетплейс
//                 </span>
//                 <span className="leading-[1]">
//                   Фильтруйте, сортируйте и выбирайте параметры именно для себя
//                 </span>
//               </div>
//             </div>
//             <Button size="lg" outline className="self-center">
//               Создать аккаунт прямо сейчас
//             </Button>
//           </Container>
//         </section>
//         <section className="pt-[80px] pb-[120px] form-decor ">
//           <Container className="flex justify-between backdrop-blur-[60px]">
//             <div className="flex flex-col gap-[48px] max-w-[593px]">
//               <Badge className="self-start">Форма для связи</Badge>
//               <h2 className="text-h2 leading-[1]">
//                 Не&nbsp;нашли&nbsp;мощности для себя?
//               </h2>
//               <span className="text-subtitle leading-[1.1]">
//                 Напишите&nbsp;нам&nbsp;и&nbsp;мы&nbsp;с&nbsp;радостью&nbsp;поможем&nbsp;и
//                 подберем вам сервер по вашим пожеланиям
//               </span>
//             </div>
//             <ContactForm className="min-w-[540px]" />
//           </Container>
//         </section>
//       </main>
//       {/* на гриды переписать */}
//       {/* <footer className="w-full">
//         <Container className="flex justify-between">
//           <div className="flex flex-col border border-red-300">
//             <a
//               href="#"
//               className="bg-[url(/logo.svg)] w-[145px] h-[39px]"
//             ></a>
//             <span>&copy;&nbsp;QuData, 2025</span>
//           </div>
//           <div className="flex flex-col">
//             <h4>Общее</h4>
//             <nav>
//               <ul className="flex flex-col">
//                 <li>Цены</li>
//                 <li>О нас</li>
//                 <li>FAQ</li>
//                 <li>Блог</li>
//                 <li>Документация</li>
//               </ul>
//             </nav>
//           </div>
//           <div className="flex flex-col">
//             <h4>Социальные сети</h4>
//             <nav>
//               <ul className="flex flex-col">
//                 <li>Instagram</li>
//                 <li>Telegram</li>
//                 <li>Twitter</li>
//               </ul>
//             </nav>
//           </div>
//           <div className="flex flex-col">
//             <h4>Для разработчиков</h4>
//             <nav>
//               <ul className="flex flex-col">
//                 <li>Документация</li>
//                 <li>GitHub</li>
//               </ul>
//             </nav>
//           </div>
//           <div className="flex flex-col">
//             <h4>Связаться</h4>
//             <a href="">qudata@info.ru</a>
//           </div>
//         </Container>
//       </footer> */}
//       <footer className="w-full border-t border-dimmed-12">
//         <Container className="grid grid-cols-[minmax(0,_273px)_minmax(0,_230px)_minmax(0,_285px)_minmax(0,_304px)_minmax(0,_348px)] border-l border-r border-dimmed-12">
//           <div className="flex flex-col items-center border-r border-dimmed-12">
//             <div className="flex flex-col gap-[32px] pt-[64px] ">
//               <a
//                 href="#"
//                 className="bg-[url(/logo.svg)] w-[145px] h-[39px]"
//               ></a>
//               <span>&copy;&nbsp;QuData, 2025</span>
//             </div>
//           </div>
//           {/* <div className="pt-[64px] flex flex-col"> */}
//           <div className="flex flex-col items-center border-r border-dimmed-12">
//             <div className="pt-[64px]">
//               <h4 className="text-h4 text-dimmed-25 leading-[1] mb-[32px]">
//                 Общее
//               </h4>
//               <nav>
//                 <ul className="flex flex-col gap-[24px] text-[16px] text-white leading-[1] ">
//                   <li>
//                     <a href="#">Цены</a>
//                   </li>
//                   <li>
//                     <a href="#">О нас</a>
//                   </li>
//                   <li>
//                     <a href="#">FAQ</a>
//                   </li>
//                   <li>
//                     <a href="#">Блог</a>
//                   </li>
//                   <li>
//                     <a href="#">Документация</a>
//                   </li>
//                 </ul>
//               </nav>
//             </div>
//           </div>
//           {/* <div className="pt-[64px] flex flex-col"> */}

//           <div className="flex flex-col items-center border-r border-dimmed-12">
//             <div className="pt-[64px]">
//               <h4 className="text-h4 text-dimmed-25 leading-[1] mb-[32px]">
//                 Социальные сети
//               </h4>
//               <nav>
//                 <ul className="flex flex-col gap-[24px] text-[16px] text-white leading-[1] ">
//                   <li>
//                     <a href="#">Instagram</a>
//                   </li>
//                   <li>
//                     <a href="#">Telegram</a>
//                   </li>
//                   <li>
//                     <a href="#">Twitter</a>
//                   </li>
//                 </ul>
//               </nav>
//             </div>
//           </div>
//           {/* <div className="pt-[64px] flex flex-col"> */}
//           <div className="flex flex-col items-center border-r border-dimmed-12">
//             <div className="pt-[64px]">
//               <h4 className="text-h4 text-dimmed-25 leading-[1] mb-[32px]">
//                 Для разработчиков
//               </h4>
//               <nav>
//                 <ul className="flex flex-col gap-[24px] text-[16px] text-white leading-[1] ">
//                   <li>
//                     <a href="#">Документация</a>
//                   </li>
//                   <li>
//                     <a href="#">GitHub</a>
//                   </li>
//                 </ul>
//               </nav>
//             </div>
//           </div>
//           {/* <div className="pt-[64px] flex flex-col"> */}
//           <div className="flex flex-col ">
//             <div className="p-[64px]">
//               <h4 className="text-h4 text-dimmed-25 leading-[1] mb-[32px]">
//                 Связаться
//               </h4>
//               <a
//                 href="mailto:qudata@info.ru"
//                 className="text-[16px] text-white leading-[1]"
//               >
//                 qudata@info.ru
//               </a>
//             </div>
//             <div className="py-[50px] px-[64px] flex flex-col gap-[32px] border-t border-dimmed-12 text-[16px] leading-[1] text-dimmed-25">
//               <a href="">Политика&nbsp;конфиденциальности</a>
//               <a href="">Договор&nbsp;оферты</a>
//             </div>
//           </div>
//         </Container>
//         <span className="py-[48px] flex justify-center text-[14px] text-dimmed-40 leading-[16px] border-t border-dimmed-12">
//           &copy; Все права защищены. 2025, Москва
//         </span>
//       </footer>
//     </>
//   );
// }

// export default function Home() {
//   return <LandingPage />;
// }
